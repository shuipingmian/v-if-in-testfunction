<template>
  <div class="page" v-show="isVisible" id="computont">
    <div @click="uio('hhh')"><button>点击关闭兄弟组件的方法</button></div>
    <div>我是子组件CCCC</div>
  </div>
</template>

<script type="text/ecmascript-6">
  import visibilityMixin from "../common/visibei"
    export default {
      mixins:[ visibilityMixin],
      data() {
        return {
         name:"ccc"
        }
      },
      components: {

      },
      methods: {
      uio(name) {
        let i =  this.findcomputed(name)  //在混入里面我定义了 一个方法根据data 中的name 查找数组的位置
        if (this.$parent.$children[i].isVisible) {
          this.$parent.$children[i].hide()
        } else {
         this.$parent.$children[i].show()
        }
      }
    }
    }
</script>

<style scoped>
  .page {
    width: 200px;
    height: 660px;
    background-color: red;
  }
</style>
