
components.map = {
  data: {
    center: [89, 35],
    zoom: 5
  },
  config: {
    view: {
      mapStyle: 'amap://styles/736055c2b48192cbffc2c010951c5056',
      viewMode: '3D',
      pitch: 20,
      center: [89, 35],
      zoom: 5,
      zooms: [3, 20],
      features: ['bg', 'road', 'point']
    },
    layers: [
      {
        type: 'Tile',
        options: {
          opacity: 0.85
        }
      }
    ]
  }
};

components.areas = {
  api: {
    url: api + '?oid=598976535695e25b7c3f139f'
  },
  data: []
};

components.cities = {
  api: {
    url: api + '?oid=598981735695e25b7c3f13a0'
  },
  data: []
};

components.counties = {
  api: {
    url: api + '?oid=5989834d5695e25b7c3f13a1'
  },
  data: []
};

components.community = {
  api: {
    url: api + '?oid=5e3bae7e0e8b6e00b8fa8733&sort=confirm&order=ascending',
    callback: function (ctx, data) {
      ctx.community.api.data = data;
    },
    data: []
  },
  data: [],
  config: {
    point: {
      type: 'point'
    },
    style: {
      radius: 0.35,
      color: function (item) {
        var data = item.value;
        var value = data.value;
        if (value >= 5) {
          return '#ff1111';
        } else if (value >= 2) {
          return '#f06427';
        } else if (value >= 1) {
          return '#f5d022';
        }
        return '#1dd8e4';
      },
      borderWidth: 0,
      opacity: 0.65
    },
    events: {
      click: function (ctx, data, event) {
        ctx.modal.data = {
          address: data.address,
          name: '累计确诊',
          value: Math.max(data.value, 0),
          suffix: '例'
        };
        ctx.modal.position = [event.x, event.y];
        ctx.modal.show = true;
      }
    }
  },
  show: true
};

components.province = {
  data: [],
  config: {
    district: {
      depth: 1,
      zIndex: 5,
      styles: {
        'province-stroke': '#052f40'
      }
    }
  },
  show: false
};

components.county = {
  api: {
    url: api + '?oid=5e3521f80e8b6e00b8fa7d99',
    callback: function (ctx, data) {
      var codes = [110000, 120000, 310000, 500000];
      var cities = ctx.cities.data;
      data.forEach(function (d) {
        var name = ctx.normalizeName(d.city);
        cities.some(function (city) {
          if (city.name.indexOf(name) === 0) {
            var adcode = Number(city.adcode);
            if (codes.indexOf(adcode) === -1) {
              codes.push(adcode);
            }
            return true;
          }
          return false;
        });
      });
      ctx.county.codes = codes;
      ctx.county.api.data = data;
    },
    data: []
  },
  data: [],
  config: {
    district: {
      level: 'Province',
      adcode: [330100],
      depth: 2,
      zIndex: 15,
      styles: {
        'province-stroke': '#052f40',
        'city-stroke': '#052f40',
        'county-stroke': 'rgba(5,47,64,0.35)'
      }
    }
  },
  show: false,
  codes: []
};

components.district = {
  api: {
    url: api + '?oid=5e30f2676eaa0e00b210ca79&filters=name&name=中国&unwrap=true',
    callback: function (ctx, data) {
      var district = ctx.state.district;
      ctx.district.api.data = data;
      if (district) {
        ctx.searchInput.data.value = district;
        ctx.searchArea({ value: district });
      } else {
        ctx.setCityData(data);
      }
    },
    data: []
  },
  data: [],
  config: {
    district: {
      depth: 2,
      zIndex: 10,
      styles: {
        'province-stroke': '#052f40',
        'city-stroke': 'rgba(5,47,64,0.35)'
      }
    }
  },
  show: true
};

components.levelType = {
  data: [
    {
      name: 'level',
      value: 'province',
      content: '省',
      active: false
    },
    {
      name: 'level',
      value: 'city',
      content: '市',
      active: true
    }
  ]
};

components.countType = {
  data: [
    {
      name: 'count',
      value: 'total',
      content: '累计',
      active: true
    },
    {
      name: 'count',
      value: 'today',
      content: '新增',
      active: false
    }
  ],
  config: {
    value: {
      display: 'inline-block',
      marginRight: '0.5rem',
      fontSize: '0.85rem',
      lineHeight: 2
    },
    active: {
      color: '#40a9ff'
    }
  }
};

components.radio = {
  data: [
    {
      name: 'type',
      value: 'confirm',
      content: '确诊',
      active: true,
      color: '#40a9ff'
    },
    {
      name: 'type',
      value: 'heal',
      content: '治愈',
      active: false,
      color: '#24f81f'
    },
    {
      name: 'type',
      value: 'dead',
      content: '死亡',
      active: false,
      color: '#fc3f14'
    },
    {
      name: 'type',
      value: 'healRate',
      content: '治愈率',
      active: false,
      color: '#24f81f',
      display: 'inline-block'
    },
    {
      name: 'type',
      value: 'deadRate',
      content: '死亡率',
      active: false,
      color: '#fc3f14',
      display: 'inline-block'
    },
  ],
  config: {
    value: {
      display: 'inline-block',
      marginRight: '0.5rem',
      fontSize: '0.85rem',
      lineHeight: 2
    }
  }
};

components.legend = {
  data: [],
  config: {
    content: {
      display: 'inline-block',
      color: '#fff',
      fontSize: '0.75rem',
      width: '2.95rem',
      borderTop: '0.5rem solid #fff'
    },
    items: []
  }
};

components.searchInput = {
  data: {
    placeholder: '省 | 市 ',
    value: '',
    suffix: '<i class="fas fa-search"></i>'
  },
  config: {
    group: {
      color: '#00ffff',
    },
    input: {
      fontSize: '0.85rem',
      border: '1px solid #00ffff',
    },
    focus: {
      borderColor: '#00ffff',
    },
    placeholder: {
      color: 'rgba(0, 255, 255,0.65)'
    },
    suffix: {
      padding: '0.1rem 0.5rem 0',
      fontSize: '1rem',
      border: '1px solid #00ffff',
      borderLeft: 'none',
      background: '#052f40'
    },
  }
};

components.table = {
  data: [],
  config: {
    columns: [
      {
        prop: 'name',
        label: '地区',
        width: '7rem'
      },
      {
        prop: 'confirmIncrement',
        label: '新增确诊',
        width: '5rem'
      },
      {
        prop: 'confirm',
        label: '累计确诊',
        width: '5rem'
      },
      {
        prop: 'heal',
        label: '治愈',
        width: '3.5rem'
      },
      {
        prop: 'dead',
        label: '死亡',
        width: '3.5rem'
      },
    ],
    table: {
      padding: '0.25rem 0.5rem',
      lineHeight: 2,
      background: 'rgba(5,47,64,0.65)'
    },
    thead: {
      color: '#fff',
      fontSize: '1rem',
      background: 'rgba(5,47,64,1)'
    },
    span: {
      color: 'rgba(255,255,255,0.8)',
      fontSize: '1rem',
      lineHeight: 1.7
    },
    name: {
      color: '#00ffff',
      fontSize: '0.85rem'
    },
    striped: {
      even: 'rgba(5,47,64,0.65)'
    }
  },
  animation: {
    minRows: 24,
    duration: '1s'
  },
  container: {
    border: '1px solid #00ffff',
    maxHeight: '48rem'
  },
  show: false
};

components.modal = {
  data: {},
  config: {
    modal: {
      background: 'rgba(5,47,64,0.65)',
      border: '1px solid #00ffff'
    },
    body: {
      color: '#00ffff',
      fontSize: '1rem',
      paddingTop: '1rem'
    }
  },
  marker: {
    display: 'block',
    width: '1.25rem',
    padding: '0.35rem 0',
    float: 'left'
  },
  address: {
    display: 'block'
  },
  confirm: {
    stats: {
      marginLeft: '1.25rem',
      marginTop: '1rem',
      width: '12rem'
    },
    content: {
      color: '#40a9ff'
    }
  },
  position: [],
  show: false
};
