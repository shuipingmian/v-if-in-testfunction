
components.last = {
  api: {
    url: api + '?oid=5e2e7f720e8b6e00b8fa7412&sort=date&limit=2',
  },
  data: []
};

components.current = {
  api: {
    url: api + '?oid=5e311cc36eaa0e00b210cac9',
    callback: function (ctx, data) {
      var d0 = data;
      var d1 = ctx.last.data[0];
      ctx.confirm.data = {
        id: 'confirm-' + Date.now(),
        name: '确诊',
        value: Number(d0.confirm),
        initial: Number(d1.confirm),
        suffix: '例'
      };
      ctx.suspect.data = {
        id: 'suspect-' + Date.now(),
        name: '疑似',
        value: Number(d0.suspect),
        initial: Number(d1.suspect),
        suffix: '例'
      };
      ctx.heal.data = {
        id: 'heal-' + Date.now(),
        name: '治愈',
        value: Number(d0.heal),
        initial: Number(d1.heal),
        suffix: '人'
      };
      ctx.dead.data = {
        id: 'dead-' + Date.now(),
        name: '死亡',
        value: Number(d0.dead),
        initial: Number(d1.dead),
        suffix: '人'
      };
      ctx.current.api.data = data;
    },
    data: {}
  },
  data: {}
};

components.heading = {
  data: {
    content: '中国'
  },
  config: {
    title: {
      color: '#00ffff',
      fontSize: '1.5rem'
    }
  },
  show: false
};

components.confirm = {
  data: {},
  config: {
    content: {
      color: '#40a9ff'
    }
  },
  top: 5.75
};

components.suspect = {
  data: {},
  config: {
    content: {
      color: '#ffcd03'
    }
  }
};

components.heal = {
  data: {},
  config: {
    content: {
      color: '#24f81f'
    }
  },
  left: 3,
  top: 11
};

components.dead = {
  data: {},
  config: {
    content: {
      color: '#fc3f14'
    }
  },
  top: 11
};

components.confirmIncrement = {
  data: {},
  top: 8
};

components.suspectIncrement = {
  data: {}
};

components.healIncrement = {
  data: {}
};

components.deadIncrement = {
  data: {}
};

components.trend = {
  api: {
    url: api + '?oid=5e2e7f720e8b6e00b8fa7412&sort=date&limit=14',
    callback: function (ctx, data) {
      ctx.trend.api.data = data;
      ctx.setTrendData(data);
    },
    data: []
  },
  data: []
};

components.zhenduan = {
  data: [],
  config: {
    padding: [2.5, 1, 2.5, 3],
    scales: {
      y: {
        min: 0,
        tickCount: 5,
        minTickInterval: 1
      }
    },
    line: {
      shape: 'smooth',
      color: {
        field: 's',
        mapping: ['#40a9ff', '#ffcd03']
      }
    },
    point: {
      shape: 'circle',
      color: {
        field: 's',
        mapping: ['#40a9ff', '#ffcd03']
      }
    },
    tooltip: {
      show: false
    },
    legend: {
      marker: 'circle',
      position: 'top-right',
      textStyle: {
        fontSize: 0.85
      }
    }
  },
  show: true
};

components.zhiliao = {
  data: [],
  config: {
    padding: [2.5, 3, 2.5, 3],
    scales: {
      y: {
        min: 0,
        tickCount: 5,
        minTickInterval: 1
      },
      z: {
        tickCount: 4,
        minTickInterval: 0.5,
        formatter: function (text) {
          var value = Number(Number(text).toFixed(2));
          if (value > 0) {
            return value + '%';
          } else if (value === 0) {
            return 0;
          }
          return '';
        }
      }
    },
    line: {
      shape: 'smooth',
      color: {
        field: 's',
        mapping: ['#24f81f', '#fc3f14']
      }
    },
    point: {
      shape: 'circle',
      color: {
        field: 's',
        mapping: ['#24f81f', '#fc3f14']
      }
    },
    tooltip: {
      show: false
    },
    legend: {
      custom: true,
      position: 'top-right',
      clickable: false,
      hoverable: false,
      items: [
        {
          value: '治愈人数',
          marker: {
            symbol: 'circle',
            fill: '#24f81f'
          }
        },
        {
          value: '死亡人数',
          marker: {
            symbol: 'circle',
            fill: '#fc3f14'
          }
        },
        {
          value: '死亡率',
          marker: {
            symbol: 'square',
            fill: '#ff7327'
          }
        },
      ],
      textStyle: {
        fontSize: 0.85
      }
    },
    extend: function (ctx, chart) {
      chart.line()
           .position('x*z')
           .shape('smooth')
           .color('#ff7327')
           .style({
             lineDash: [2, 2]
           });
      chart.axis('z', {
        label: {
          offset: Vue.util.vw2px(0.5),
          textStyle: {
            fontSize: Vue.util.vw2px(0.75),
            fill: '#fff'
          }
        },
        grid: null
      });
    }
  },
  show: true
};

components.increment = {
  api: {
    url: api + '?oid=5e367259238f4a00b16adbab&sort=date&limit=14',
    callback: function (ctx, data) {
      var d0 = data[0];
      ctx.confirmIncrement.data = {
        id: 'confirm-' + Date.now(),
        name: '新增确诊',
        value: Number(d0.confirm),
        suffix: '例'
      };
      ctx.suspectIncrement.data = {
        id: 'suspect-' + Date.now(),
        name: '新增疑似',
        value: Number(d0.suspect),
        suffix: '例'
      };
      ctx.healIncrement.data = {
        id: 'heal-' + Date.now(),
        name: '新增治愈',
        value: Number(d0.heal),
        suffix: '人'
      };
      ctx.deadIncrement.data = {
        id: 'dead-' + Date.now(),
        name: '新增死亡',
        value: Number(d0.dead),
        suffix: '人'
      };

      var zhenduanIncrement = [];
      var zhiliaoIncrement = [];
      data.forEach(function (d) {
        var x = String(d.date).replace(/^0/, '').replace(/\.0?/, '\/');
        zhiliaoIncrement.unshift({
          s: '死亡人数',
          x: x,
          y: Number(d.dead)
        });
        zhenduanIncrement.unshift({
          s: '疑似病例',
          x: x,
          y: Number(d.suspect)
        });
        zhenduanIncrement.unshift({
          s: '确诊病例',
          x: x,
          y: Number(d.confirm)
        });
        zhiliaoIncrement.unshift({
          s: '治愈人数',
          x: x,
          y: Number(d.heal)
        });
      });
      ctx.zhenduanIncrement.data = zhenduanIncrement;
      ctx.zhiliaoIncrement.data = zhiliaoIncrement;
      ctx.increment.api.data = data;
    },
    data: []
  },
  data: []
};

components.zhenduanIncrement = {
  data: [],
  config: {
    padding: [2.5, 1, 2.5, 3],
    scales: {
      y: {
        min: 0,
        tickCount: 5
      }
    },
    line: {
      shape: 'smooth',
      color: {
        field: 's',
        mapping: ['#40a9ff', '#ffcd03']
      }
    },
    point: {
      shape: 'circle',
      color: {
        field: 's',
        mapping: ['#40a9ff', '#ffcd03']
      }
    },
    tooltip: {
      show: false
    },
    legend: {
      marker: 'circle',
      position: 'top-right',
      textStyle: {
        fontSize: 0.85
      }
    }
  }
};

components.zhiliaoIncrement = {
  data: [],
  config: {
    padding: [2.5, 1, 2.5, 3],
    scales: {
      y: {
        min: 0,
        tickCount: 5
      }
    },
    line: {
      shape: 'smooth',
      color: {
        field: 's',
        mapping: ['#24f81f', '#fc3f14']
      }
    },
    point: {
      shape: 'circle',
      color: {
        field: 's',
        mapping: ['#24f81f', '#fc3f14']
      }
    },
    tooltip: {
      show: false
    },
    legend: {
      marker: 'circle',
      position: 'top-right',
      textStyle: {
        fontSize: 0.85
      }
    }
  }
};

components.zhenduanType = {
  data: [
    {
      name: 'zhenduan',
      value: 'total',
      content: '累计',
      active: true
    },
    {
      name: 'zhenduan',
      value: 'increment',
      content: '新增',
      active: false
    }
  ],
  config: {
    value: {
      display: 'inline-block',
      marginRight: '0.5rem',
      fontSize: '1rem',
      lineHeight: 2
    },
    active: {
      color: '#00ffff'
    }
  }
};

components.zhiliaoType = {
  data: [
    {
      name: 'zhiliao',
      value: 'total',
      content: '累计',
      active: true
    },
    {
      name: 'zhiliao',
      value: 'increment',
      content: '新增',
      active: false
    }
  ],
  config: {
    value: {
      display: 'inline-block',
      marginRight: '0.5rem',
      fontSize: '1rem',
      lineHeight: 2
    },
    active: {
      color: '#00ffff'
    }
  }
};

components.provinceTrend = {
  api: {
    url: api + '?oid=5e3562be0e8b6e00b8fa7de6&filters=adcode&adcode=:adcode&sort=date&limit=14',
    callback: function (ctx, data) {
      var adcode = ctx.state.adcode;
      if (adcode !== -1 && adcode % 10000 === 0) {
        ctx.setTrendData(data);
      }
    }
  },
  data: []
};

components.cityTrend = {
  api: {
    url: api + '?oid=5e3569900e8b6e00b8fa7df7&filters=adcode&adcode=:adcode&sort=date&limit=14',
    callback: function (ctx, data) {
      var adcode = ctx.state.adcode;
      if (adcode !== -1 && adcode % 10000 !== 0) {
        ctx.setTrendData(data);
      }
    }
  },
  data: []
};
