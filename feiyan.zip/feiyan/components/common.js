var api = 'https://datam.youlishu.com/dataset/json';
var components = {};
components.debug = false;
components.draggable = true;
components.state = {
  adcode: -1,
  district: '',
  center: '',
  zoom: 0,
  level: 'city',
  count: 'total',
  type: 'confirm',
  min: 1,
  max: 1000000
};
components.bgScreen = {
  data: {
    url: './images/bg-screen.png'
  }
};
components.bgHeader = {
  data: {
    url: './images/bg-header.png'
  }
};
components.bgSection1 = {
  data: {
    url: './images/bg-section-sm.png'
  }
};
components.bgSection2 = {
  data: {
    url: './images/bg-section-lg.png'
  }
};
components.vbsLogo = {
  data: {
    url: './images/logo-vbs.png'
  }
};
components.ylsLogo = {
  data: {
    url: './images/logo-yls.png'
  }
};
components.skkjLogo = {
  data: {
    url: './images/logo-skkj.png'
  }
};
components.credit = {
  data: {
    image: 'https://pm.youlishu.com/public/images/favicon.png',
    content: '有理数',
    separator: '·',
    subtitle: '可视化大脑联合实验室'
  },
  config: {
    title: {
      color: '#b1e6fd',
      fontSize: '1rem',
      textAlign: 'left'
    },
    separator: {
      padding: '0 0.25rem'
    }
  }
};
components.screen = {
  data: {
    content: '新型冠状病毒肺炎疫情地图'
  },
  config: {
    title: {
      color: '#00ffff',
      fontSize: '2rem',
      fontWeight: 'bold',
      letterSpacing: '0.1rem'
    }
  },
  unit: window.innerWidth > 576 ? '' : 12,
  fit: window.innerWidth > 576 ? 'viewport' : ''
};
components.datetime = {
  data: {},
  config: {
    datetime: {
      color: '#fff',
      fontSize: '1rem',
      textAlign: 'right'
    },
    weekday: {
      values: ['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六']
    },
    seconds: {
      color: '#fff'
    }
  }
};

components.stats = {
  config: {
    stats: {
      color: '#fff',
      fontSize: '1.2rem'
    },
    title: {
      display: 'inline-block'
    },
    content: {
      float: 'right'
    },
    number: {
      fontSize: '150%',
      lineHeight: 1
    },
    digit: {
      display: 'inline-block',
      lineHeight: 1,
      fontWeight: 'bold',
      margin: 0
    },
    suffix: {
      fontSize: '1rem'
    }
  },
  animation: {
    name: 'anime',
    duration: 1.5,
    delay: 0,
    steps: 100
  }
};
