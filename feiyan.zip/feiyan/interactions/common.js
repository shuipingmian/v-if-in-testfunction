var interactions = {};

interactions.closeModal = function () {
  this.modal.show = false;
};

interactions.resetMap = function (item) {
  this.state.adcode = -1;
  this.state.district = '';
  this.state.center = '';
  this.state.zoom = 0;
  this.table.show = false;
  this.searchInput.data.value = '';
  this.searchArea({ value: '' });
  this.setCountType({ value: 'total' });
  this.setTrendData(this.trend.api.data);
};

interactions.setZhenduanType = function (item) {
  var type = item.value;
  if (type === 'total') {
    this.zhenduan.show = true;
  } else if (type === 'increment') {
    this.zhenduan.show = false;
  }
};

interactions.setZhiliaoType = function (item) {
  var type = item.value;
  if (type === 'total') {
    this.zhiliao.show = true;
  } else if (type === 'increment') {
    this.zhiliao.show = false;
  }
};

interactions.toggleMapLayer = function () {
  var level = this.state.level;
  var data = this.district.api.data;
  if (level === 'province') {
    this.province.show = true;
    this.district.show = false;
    this.county.show = false;
    this.setProvinceData(data);
  } else if (level === 'city') {
    var adcode = this.state.adcode;
    var codes = this.county.codes;
    this.province.show = false;
    if (codes.indexOf(adcode) !== -1) {
      this.district.show = false;
      this.county.show = true;
      this.county.config.district.adcode = [adcode];
      this.setCountyData(data);
    } else {
      this.district.show = true;
      this.county.show = false;
      this.setCityData(data);
    }
  }
};

interactions.setCommunityPoints = function () {
  var ctx = this;
  var adcode = Number(ctx.state.adcode);
  if (adcode !== -1) {
    var name = ctx.normalizeName(ctx.state.district);
    if (name && ctx.state.count === 'total' && ctx.state.type === 'confirm') {
      var data = ctx.community.api.data;
      var level = adcode % 10000 === 0 ? 'province' : 'city';
      ctx.community.data = data.filter(function (d) {
        return d[level].indexOf(name) === 0;
      }).map(function (d) {
        d.value = Number(d.confirm);
        return d;
      });
    } else {
      ctx.community.data = [];
    }
  } else {
    ctx.community.data = [];
  }
  ctx.modal.show = false;
};

interactions.setMinMax = function () {
  var count = this.state.count;
  var type = this.state.type;
  if (count === 'total' && (type === 'healRate' || type === 'deadRate')) {
    this.state.min = 0.001;
    this.state.max = 1000;
  } else {
    this.state.min = 1;
    this.state.max = 1000000;
  }
};

interactions.setLevelType = function (item) {
  this.state.level = item.value;
  this.setMinMax();
  this.toggleMapLayer();
};

interactions.setType = function (item) {
  this.state.type = item.value;
  this.setMinMax();
  this.toggleMapLayer();
  this.setCommunityPoints();
};

interactions.setCountType = function (item) {
  var count = item.value;
  var data = this.radio.data;
  if (count === 'total') {
    data[3].display = 'inline-block';
    data[4].display = 'inline-block';
  } else if (count === 'today') {
    data[3].display = 'none';
    data[4].display = 'none';
    if (data[3].active) {
      data[1].active = true;
      data[3].active = false;
      this.state.type = 'heal';
    } else if (data[4].active) {
      data[2].active = true;
      data[4].active = false;
      this.state.type = 'dead';
    }
  }
  this.state.count = count;
  this.setMinMax();
  this.toggleMapLayer();
  this.setCommunityPoints();
};

interactions.setRange = function (item) {
  var range = item.range;
  this.state.min = range[0];
  this.state.max = range[1];
  this.toggleMapLayer();
  this.setCommunityPoints();
};

interactions.setProvinceData = function (tree) {
  var ctx = this;
  var countType = ctx.state.count;
  var type = ctx.state.type;
  var min = ctx.state.min;
  var max = ctx.state.max;
  var areas = ctx.areas.data;
  var data = [];
  if (ctx.state.adcode != -1) {
    var district = ctx.state.district;
    tree.children.forEach(function (province) {
      var name = province.name;
      if (name.indexOf(district) !== -1) {
        var d = province[countType];
        d.name = name;
        data.push(d);
      }
    });
  } else {
    tree.children.forEach(function (province) {
      var d = province[countType];
      d.name = province.name;
      data.push(d);
    });
  }
  ctx.province.data = data.map(function (d) {
    var name = d.name;
    areas.some(function (area) {
      if (area.name.indexOf(name) === 0) {
        var value = Number(d[type]) || 0;
        d.adcode = Number(area.adcode);
        d.color = ctx.getColor(value);
        d.value = value;
        return true;
      }
      return false;
    });
    return d;
  }).filter(function (d) {
    var value = Number(d.value);
    return value >= min && value < max;
  });
  ctx.setMapLegend();
};

interactions.setCityData = function (tree) {
  var ctx = this;
  var countType = ctx.state.count;
  var type = ctx.state.type;
  var min = ctx.state.min;
  var max = ctx.state.max;
  var cities = ctx.cities.data;
  var areas = ['北京', '天津', '上海', '重庆', '台湾', '香港', '澳门'];
  var codes = [110000, 120000, 310000, 500000, 710000, 810000, 820000];
  var data = [];
  if (ctx.state.adcode !== -1) {
    var district = ctx.state.district;
    tree.children.forEach(function (province) {
      var area = province.name;
      if (area.indexOf(district) !== -1) {
        province.children.forEach(function (city) {
          var d = city[countType];
          d.province = area;
          d.name = city.name;
          data.push(d);
        });
      } else {
        province.children.forEach(function (city) {
          var name = city.name;
          if (name.indexOf(district) !== -1) {
            var d = city[countType];
            d.province = area;
            d.name = name;
            data.push(d);
          }
        });
      }
    });
  } else {
    tree.children.forEach(function (province) {
      var area = province.name;
      province.children.forEach(function (city) {
        var d = city[countType];
        d.province = area;
        d.name = city.name;
        data.push(d);
      });
      if (areas.indexOf(area) !== -1) {
        var d = province[countType];
        d.province = area;
        d.name = area;
        data.push(d);
      }
    });
  }
  data.forEach(function (d) {
    if (d.name === '济南') {
      data.push({
        province: d.province,
        name: '莱芜',
        confirm: d.confirm,
        suspect: d.suspect,
        heal: d.heal,
        dead: d.dead,
        healRate: d.healRate,
        deadRate: d.deadRate
      });
    }
  });
  ctx.district.data = data.map(function (d) {
    var name = ctx.normalizeName(d.name);
    var index = areas.indexOf(name);
    cities.some(function (city) {
      if (city.name.indexOf(name) === 0 || index !== -1) {
        var value = Number(d[type]) || 0;
        var adcode = Number(city.adcode);
        if (index !== -1) {
          d.adcode = codes[index];
        } else {
          d.adcode = adcode;
        }
        d.color = ctx.getColor(value);
        d.value = value;
        return true;
      }
      return false;
    });
    return d;
  }).filter(function (d) {
    var value = Number(d.value);
    return value >= min && value < max;
  });
  ctx.setMapLegend();
};

interactions.setCountyData = function (tree) {
  var ctx = this;
  var countType = ctx.state.count;
  var type = ctx.state.type;
  var min = ctx.state.min;
  var max = ctx.state.max;
  var counties = ctx.counties.data;
  var areas = ['北京', '天津', '上海', '重庆'];
  var codes = [110000, 120000, 310000, 500000];
  var data = [];
  if (ctx.state.adcode !== -1) {
    var district = ctx.state.district;
    ctx.county.api.data.forEach(function (county) {
      var area = county.city;
      if (area.indexOf(district) !== -1) {
        var d = county[countType];
        d.city = area;
        d.name = county.name;
        if (county.adcode) {
          d.adcode = Number(county.adcode);
        }
        data.push(d);
      }
    });
    tree.children.forEach(function (province) {
      var area = province.name;
      if (area.indexOf(district) !== -1) {
        province.children.forEach(function (city) {
          var d = city[countType];
          d.city = area;
          d.name = city.name;
          data.push(d);
        });
      }
    });
  } else {
    ctx.county.api.data.forEach(function (county) {
      var d = county[countType];
      d.city = county.city;
      d.name = county.name;
      if (county.adcode) {
        d.adcode = Number(county.adcode);
      }
      data.push(d);
    });
    tree.children.forEach(function (province) {
      var area = province.name;
      if (areas.indexOf(area) !== -1) {
        province.children.forEach(function (city) {
          var d = city[countType];
          d.city = area;
          d.name = city.name;
          data.push(d);
        });
      }
    });
  }
  ctx.county.data = data.map(function (d) {
    var city = d.city;
    var name = ctx.normalizeName(d.name);
    d.value = Number(d[type]) || 0;
    d.color = ctx.getColor(d.value);
    counties.some(function (county) {
      if (county.parent.indexOf(city) === 0 && county.name.indexOf(name) === 0) {
        var adcode = Number(county.adcode);
        if (adcode === 310230) {
          adcode = 310151;
        }
        d.adcode = adcode;
        return true;
      }
      return false;
    });
    return d;
  }).filter(function (d) {
    var value = Number(d.value);
    return d.adcode > 0 && value >= min && value < max;
  });
  ctx.setMapLegend();
};

interactions.getColor = function (value) {
  var ctx = this;
  var type = ctx.state.type;
  if (type === 'confirm') {
    if (value >= 1000) {
      return 'rgba(0,39,102,0.85)';
    } else if (value >= 500) {
      return 'rgba(0,58,140,0.85)';
    } else if (value >= 200) {
      return 'rgba(0,80,179,0.85)';
    } else if (value >= 100) {
      return 'rgba(9,109,217,0.85)';
    } else if (value >= 50) {
      return 'rgba(24,144,255,0.85)';
    } else if (value >= 20) {
      return 'rgba(64,169,255,0.85)';
    } else if (value >= 10) {
      return 'rgba(105,192,255,0.85)';
    } else if (value >= 5) {
      return 'rgba(145,213,255,0.85)';
    } else if (value >= 2) {
      return 'rgba(186,231,255,0.85)';
    } else if (value >= 1) {
      return 'rgba(230,247,255,0.85)';
    } else {
      return '';
    }
  } else if (type === 'heal') {
    if (value >= 1000) {
      return 'rgba(37,64,0,0.85)';
    } else if (value >= 500) {
      return 'rgba(63,102,0,0.85)';
    } else if (value >= 200) {
      return 'rgba(91,140,0,0.85)';
    } else if (value >= 100) {
      return 'rgba(124,179,5,0.85)';
    } else if (value >= 50) {
      return 'rgba(160,217,17,0.85)';
    } else if (value >= 20) {
      return 'rgba(186,230,55,0.85)';
    } else if (value >= 10) {
      return 'rgba(211,242,97,0.85)';
    } else if (value >= 5) {
      return 'rgba(234,255,143,0.85)';
    } else if (value >= 2) {
      return 'rgba(244,255,184,0.85)';
    } else if (value >= 1) {
      return 'rgba(252,255,230,0.85)';
    } else {
      return '';
    }
  } else if (type === 'dead') {
    if (value >= 1000) {
      return 'rgba(92,0,17,0.85)';
    } else if (value >= 500) {
      return 'rgba(130,0,20,0.85)';
    } else if (value >= 200) {
      return 'rgba(168,7,26,0.85)';
    } else if (value >= 100) {
      return 'rgba(207,19,34,0.85)';
    } else if (value >= 50) {
      return 'rgba(245,34,45,0.85)';
    } else if (value >= 20) {
      return 'rgba(255,77,79,0.85)';
    } else if (value >= 10) {
      return 'rgba(255,120,117,0.85)';
    } else if (value >= 5) {
      return 'rgba(255,163,158,0.85)';
    } else if (value >= 2) {
      return 'rgba(255,204,199,0.85)';
    } else if (value >= 1) {
      return 'rgba(255,241,240,0.85)';
    } else {
      return '';
    }
  } else if (type === 'healRate') {
    if (value >= 90) {
      return 'rgba(37,64,0,0.85)';
    } else if (value >= 80) {
      return 'rgba(63,102,0,0.85)';
    } else if (value >= 70) {
      return 'rgba(91,140,0,0.85)';
    } else if (value >= 60) {
      return 'rgba(124,179,5,0.85)';
    } else if (value >= 50) {
      return 'rgba(160,217,17,0.85)';
    } else if (value >= 40) {
      return 'rgba(186,230,55,0.85)';
    } else if (value >= 30) {
      return 'rgba(211,242,97,0.85)';
    } else if (value >= 20) {
      return 'rgba(234,255,143,0.85)';
    } else if (value >= 10) {
      return 'rgba(244,255,184,0.85)';
    } else if (value > 0) {
      return 'rgba(252,255,230,0.85)';
    } else {
      return '';
    }
  } else if (type === 'deadRate') {
    if (value >= 5) {
      return 'rgba(92,0,17,0.85)';
    } else if (value >= 3) {
      return 'rgba(130,0,20,0.85)';
    } else if (value >= 2.5) {
      return 'rgba(168,7,26,0.85)';
    } else if (value >= 2) {
      return 'rgba(207,19,34,0.85)';
    } else if (value >= 1.5) {
      return 'rgba(245,34,45,0.85)';
    } else if (value >= 1) {
      return 'rgba(255,77,79,0.85)';
    } else if (value >= 0.5) {
      return 'rgba(255,120,117,0.85)';
    } else if (value >= 0.2) {
      return 'rgba(255,163,158,0.85)';
    } else if (value >= 0.1) {
      return 'rgba(255,204,199,0.85)';
    } else if (value > 0) {
      return 'rgba(255,241,240,0.85)';
    } else {
      return '';
    }
  }
  return '';
};

interactions.setMapLegend = function () {
  var ctx = this;
  var type = ctx.state.type;
  if (type === 'confirm' || type === 'heal' || type === 'dead') {
    ctx.legend.data = [
      {
        content: '1',
        range: [1, 2]
      },
      {
        content: '2',
        range: [2, 5]
      },
      {
        content: '5',
        range: [5, 10]
      },
      {
        content: '10',
        range: [10, 20]
      },
      {
        content: '20',
        range: [20, 50]
      },
      {
        content: '50',
        range: [50, 100]
      },
      {
        content: '100',
        range: [100, 200]
      },
      {
        content: '200',
        range: [200, 500]
      },
      {
        content: '500',
        range: [500, 1000]
      },
      {
        content: '1000',
        range: [1000, 1000000]
      }
    ];
  } else if (type === 'healRate') {
    ctx.legend.data = [
      {
        content: '>0',
        range: [0.001, 10]
      },
      {
        content: '10%',
        range: [10, 20]
      },
      {
        content: '20%',
        range: [20, 30]
      },
      {
        content: '30%',
        range: [30, 40]
      },
      {
        content: '40%',
        range: [40, 50]
      },
      {
        content: '50%',
        range: [50, 60]
      },
      {
        content: '60%',
        range: [60, 70]
      },
      {
        content: '70%',
        range: [70, 80]
      },
      {
        content: '80%',
        range: [80, 90]
      },
      {
        content: '90%',
        range: [90, 1000]
      }
    ];
  } else if (type === 'deadRate') {
    ctx.legend.data = [
      {
        content: '>0',
        range: [0.001, 0.1]
      },
      {
        content: '1‰',
        range: [0.1, 0.2]
      },
      {
        content: '2‰',
        range: [0.2, 0.5]
      },
      {
        content: '5‰',
        range: [0.5, 1]
      },
      {
        content: '1%',
        range: [1, 1.5]
      },
      {
        content: '1.5%',
        range: [1.5, 2]
      },
      {
        content: '2%',
        range: [2, 2.5]
      },
      {
        content: '2.5%',
        range: [2.5, 3]
      },
      {
        content: '3%',
        range: [3, 5]
      },
      {
        content: '5%',
        range: [5, 1000]
      }
    ];
  }
  if (type === 'confirm') {
    ctx.legend.config.items = [
      {
        borderColor: 'rgba(230,247,255,0.85)'
      },
      {
        borderColor: 'rgba(186,231,255,0.85)'
      },
      {
        borderColor: 'rgba(145,213,255,0.85)'
      },
      {
        borderColor: 'rgba(105,192,255,0.85)'
      },
      {
        borderColor: 'rgba(64,169,255,0.85)'
      },
      {
        borderColor: 'rgba(24,144,255,0.85)'
      },
      {
        borderColor: 'rgba(9,109,217,0.85)'
      },
      {
        borderColor: 'rgba(0,80,179,0.85)'
      },
      {
        borderColor: 'rgba(0,58,140,0.85)'
      },
      {
        borderColor: 'rgba(0,39,102,0.85)'
      }
    ];
    ctx.countType.config.active = {
      color: '#40a9ff'
    };
  } else if (type === 'heal' || type === 'healRate') {
    ctx.legend.config.items = [
      {
        borderColor: 'rgba(252,255,230,0.85)'
      },
      {
        borderColor: 'rgba(244,255,184,0.85)'
      },
      {
        borderColor: 'rgba(234,255,143,0.85)'
      },
      {
        borderColor: 'rgba(211,242,97,0.85)'
      },
      {
        borderColor: 'rgba(186,230,55,0.85)'
      },
      {
        borderColor: 'rgba(160,217,17,0.85)'
      },
      {
        borderColor: 'rgba(124,179,5,0.85)'
      },
      {
        borderColor: 'rgba(91,140,0,0.85)'
      },
      {
        borderColor: 'rgba(63,102,0,0.85)'
      },
      {
        borderColor: 'rgba(37,64,0,0.85)'
      }
    ];
    ctx.countType.config.active = {
      color: '#24f81f'
    };
  } else if (type === 'dead' || type === 'deadRate') {
    ctx.legend.config.items = [
      {
        borderColor: 'rgba(255,241,240,0.85)'
      },
      {
        borderColor: 'rgba(255,204,199,0.85)'
      },
      {
        borderColor: 'rgba(255,163,158,0.85)'
      },
      {
        borderColor: 'rgba(255,120,117,0.85)'
      },
      {
        borderColor: 'rgba(255,77,79,0.85)'
      },
      {
        borderColor: 'rgba(245,34,45,0.85)'
      },
      {
        borderColor: 'rgba(207,19,34,0.85)'
      },
      {
        borderColor: 'rgba(168,7,26,0.85)'
      },
      {
        borderColor: 'rgba(130,0,20,0.85)'
      },
      {
        borderColor: 'rgba(92,0,17,0.85)'
      }
    ];
    ctx.countType.config.active = {
      color: '#fc3f14'
    };
  }
};

interactions.searchArea = function (item) {
  var ctx = this;
  var center = ctx.state.center.split(',');
  var zoom = ctx.state.zoom;
  var value = ctx.normalizeName(item.value);
  var founded = false;
  if (value) {
    var codes = [110000, 120000, 310000, 500000];
    founded = ctx.areas.data.some(function (d) {
      if (d.name.indexOf(value) !== -1) {
        var adcode = Number(d.adcode);
        if (codes.indexOf(adcode) !== -1) {
          ctx.map.data = {
            center: center.length === 2 ? center : [d.lng, d.lat],
            zoom: zoom ? zoom : 8
          };
        } else {
          ctx.map.data = {
            center: center.length === 2 ? center : [d.lng - 2, d.lat],
            zoom: zoom ? zoom : 7
          };
        }
        ctx.heading.data.content = d.name;
        ctx.state.adcode = adcode;
        return true;
      }
      return false;
    });
    if (!founded) {
      founded = ctx.cities.data.some(function (d) {
        if (d.name.indexOf(value) !== -1) {
          var adcode = Number(d.adcode);
          ctx.map.data = {
            center: center.length === 2 ? center : [d.lng, d.lat],
            zoom: zoom ? zoom : 9
          };
          ctx.heading.data.content = d.parent + d.name;
          ctx.state.level = 'city';
          ctx.state.adcode = adcode;
          return true;
        }
        return false;
      });
    }
  }
  if (founded) {
    ctx.state.district = value;
    ctx.setTableData(ctx.state.adcode, value);
  } else {
    ctx.state.adcode = -1;
    ctx.state.district = '';
    ctx.map.data = {
      center: [89, 35],
      zoom: 5
    };
    ctx.table.show = false;
  }
  ctx.state.min = 1;
  ctx.state.max = 100000;
  ctx.toggleMapLayer();
  ctx.setCommunityPoints();
};

interactions.setTrendData = function (data) {
  var ctx = this;
  var adcode = this.state.adcode;
  var latest = data[0];
  var zhenduanData = [];
  var zhiliaoData = [];
  data.forEach(function (d) {
    var x = String(d.date).replace(/^0/, '').replace(/\.0?/, '\/');
    if (adcode === -1) {
      zhenduanData.unshift({
        s: '疑似病例',
        x: x,
        y: Number(d.suspect)
      });
    }
    zhenduanData.unshift({
      s: '确诊病例',
      x: x,
      y: Number(d.confirm)
    });
    if (adcode === -1 || Number(latest.confirm) > 0) {
      zhiliaoData.unshift({
        s: '死亡人数',
        x: x,
        y: Number(d.dead),
        z: Number(d.dead) / Number(d.confirm) * 100
      });
      zhiliaoData.unshift({
        s: '治愈人数',
        x: x,
        y: Number(d.heal),
        z: Number(d.dead) / Number(d.confirm) * 100
      });
    } else {
      zhiliaoData.unshift({
        s: '死亡人数',
        x: x,
        y: Number(d.dead)
      });
      zhiliaoData.unshift({
        s: '治愈人数',
        x: x,
        y: Number(d.heal)
      });
    }
  });
  ctx.zhenduan.data = zhenduanData;
  ctx.zhiliao.data = zhiliaoData;
  if (adcode === -1) {
    if (ctx.heading.show) {
      var d0 = ctx.current.api.data;
      var d1 = ctx.last.data[0];
      var increment = ctx.increment.api.data[0];
      ctx.confirm.data = {
        id: 'confirm-' + Date.now(),
        name: '确诊',
        value: Number(d0.confirm),
        initial: Number(d1.confirm),
        suffix: '例'
      };
      ctx.confirmIncrement.data = {
        id: 'suspect-' + Date.now(),
        name: '新增确诊',
        value: Number(increment.confirm),
        suffix: '例'
      };
      ctx.heal.data = {
        id: 'heal-' + Date.now(),
        name: '治愈',
        value: Number(d0.heal),
        initial: Number(d1.heal),
        suffix: '人'
      };
      ctx.dead.data = {
        id: 'dead-' + Date.now(),
        name: '死亡',
        value: Number(d0.dead),
        initial: Number(d1.dead),
        suffix: '人'
      };
    }
    ctx.zhenduanType.data = [
      {
        name: 'zhenduan',
        value: 'total',
        content: '累计',
        active: true
      },
      {
        name: 'zhenduan',
        value: 'increment',
        content: '新增',
        active: false
      }
    ];
    ctx.zhiliaoType.data = [
      {
        name: 'zhiliao',
        value: 'total',
        content: '累计',
        active: true
      },
      {
        name: 'zhiliao',
        value: 'increment',
        content: '新增',
        active: false
      }
    ];
    ctx.confirm.top = 5.75;
    ctx.confirmIncrement.top = 8;
    ctx.heal.left = 3;
    ctx.heal.top = 11;
    ctx.dead.top = 11;
    ctx.heading.show = false;
  } else {
    var stats = ctx.getDistrictData(adcode, ctx.state.district);
    var total = stats.total || latest || {};
    var today = stats.today || {};
    ctx.confirm.data = {
      id: 'confirm-' + Date.now(),
      name: '确诊',
      value: Number(total.confirm),
      suffix: '例'
    };
    ctx.confirmIncrement.data = {
      id: 'suspect-' + Date.now(),
      name: '新增确诊',
      value: Number(today.confirm || 0),
      suffix: '例'
    };
    ctx.heal.data = {
      id: 'heal-' + Date.now(),
      name: '治愈',
      value: Number(total.heal),
      suffix: '人'
    };
    ctx.dead.data = {
      id: 'dead-' + Date.now(),
      name: '死亡',
      value: Number(total.dead),
      suffix: '人'
    };
    ctx.zhenduanType.data = [
      {
        name: 'zhenduan',
        value: 'total',
        content: '累计',
        active: true
      }
    ];
    ctx.zhiliaoType.data = [
      {
        name: 'zhiliao',
        value: 'total',
        content: '累计',
        active: true
      }
    ];
    ctx.confirm.top = 9.5;
    ctx.confirmIncrement.top = 12.5;
    ctx.heal.left = 17;
    ctx.heal.top = 9.5;
    ctx.dead.top = 12.5;
    ctx.heading.show = true;
  }
  ctx.zhenduan.show = true;
  ctx.zhiliao.show = true;
};

interactions.getDistrictData = function (adcode, district) {
  var ctx = this;
  var data = ctx.district.api.data;
  var name = ctx.normalizeName(district);
  var districtData = {};
  if (adcode % 10000 === 0) {
    data.children.some(function (province) {
      if (province.name.indexOf(name) === 0) {
        districtData = {
          name: province.name,
          total: province.total,
          today: province.today
        };
        return true;
      }
      return false;
    });
  } else if (adcode % 100 === 0) {
    data.children.some(function (province) {
      return province.children.some(function (city) {
        if (city.name.indexOf(name) === 0) {
          districtData = city;
          return true;
        }
        return false;
      });
    });
  }
  return districtData;
};

interactions.setTableData = function (adcode, district) {
  var ctx = this;
  var name = ctx.normalizeName(district);
  var tableData = [];
  if (adcode % 10000 === 0) {
    ctx.district.api.data.children.some(function (province) {
      if (province.name.indexOf(name) === 0) {
        tableData = province.children.map(function (city) {
          var total = city.total || {};
          var today = city.today || {};
          var props = [];
          var colors = [];
          var d = {
            name: city.name,
            confirmIncrement: today.confirm,
            confirm: total.confirm,
            heal: total.heal,
            dead: total.dead
          };
          if (d.confirmIncrement > 0) {
            props.push('confirmIncrement');
            colors.push('#40a9ff');
          }
          if (d.confirm > 0) {
            props.push('confirm');
            colors.push('#40a9ff');
          }
          if (d.heal > 0) {
            props.push('heal');
            colors.push('#24f81f');
          }
          if (d.dead > 0) {
            props.push('dead');
            colors.push('#fc3f14');
          }
          if (colors.length) {
            d.props = props;
            d.colors = colors;
          }
          return d;
        });
        return true;
      }
      return false;
    });
  } else if (adcode % 100 === 0) {
    ctx.county.api.data.forEach(function (county) {
      if (county.city.indexOf(name) === 0) {
        var total = county.total || {};
        var today = county.today || {};
        var props = [];
        var colors = [];
        var d = {
          name: county.name,
          confirmIncrement: today.confirm,
          confirm: total.confirm,
          heal: total.heal,
          dead: total.dead
        };
        if (d.confirmIncrement > 0) {
          props.push('confirmIncrement');
          colors.push('#40a9ff');
        }
        if (d.confirm > 0) {
          props.push('confirm');
          colors.push('#40a9ff');
        }
        if (d.heal > 0) {
          props.push('heal');
          colors.push('#24f81f');
        }
        if (d.dead > 0) {
          props.push('dead');
          colors.push('#fc3f14');
        }
        if (props.length) {
          d.props = props;
          d.colors = colors;
        }
        tableData.push(d);
      }
    });
  }
  tableData.sort(function (a, b) {
    if (a.name.indexOf('待确认') !== -1 || a.name.indexOf('其他') !== -1 || a.name.indexOf('武汉籍') !== -1) {
      return 1;
    }
    return Number(b.confirm) - Number(a.confirm);
  });
  ctx.table.data = tableData;
  ctx.table.show = tableData.length > 1;
};

interactions.normalizeName = function (name) {
  name = String(name).trim();
  if (name.length >= 3 && name.indexOf('待确认') === -1) {
    return name.replace(/(省|市|县|区|盟|州|自治州|自治县|示范区).*$/, '');
  }
  return name;
};
